export interface Creditcard {
  cardNumber: string;
  cardHolderName: string;
  expirationDate: string;
  // expirationMonth: string;
  // expirationYear: string;
  totalAmount: number;
  cvv: string;
}
