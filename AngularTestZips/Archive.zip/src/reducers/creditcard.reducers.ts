import { Action} from '@ngrx/store';
import { Creditcard} from '../models/creditcard.model'
import * as CreditcardActions from '../actions/creditcard.actons';

const initialState: Creditcard = {
    cardNumber: '1172 2424 2141 1233',
    cardHolderName: 'KRISHNANATH MALY',
    expirationDate: '10/2022',
    expirationMonth: '10',
    expirationYear: '2022',
    totalAmount: '777',
    cvv: '888'
    
}

export function reducer(state: Creditcard[]= [initialState], action: CreditcardActions.Actions){

    switch(action.type){
        case CreditcardActions.ADD_CREDITCARD:

          return[...state, action.payload];
          default:
             return state;

    }
}