import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-credicard',
  templateUrl: './add-credicard.component.html',
  styleUrls: ['./add-credicard.component.scss']
})
export class AddCredicardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
