import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreditCardDTOComponent } from './credit-card-dto/credit-card-dto.component';
import { InteractivePaycardModule } from 'ngx-interactive-paycard';
import { StoreModule } from '@ngrx/store';
import { reducer } from '../reducers/creditcard.reducers';
import { AddCredicardComponent } from './pages/add-credicard/add-credicard.component';
import { ReadCredicardComponent } from './pages/read-credicard/read-credicard.component';


@NgModule({
  declarations: [
    AppComponent,
     CreditCardDTOComponent,
     AddCredicardComponent,
     ReadCredicardComponent
  ],
  imports: [
    BrowserModule,
    StoreModule.forRoot({
      creditcard: reducer
    }),
    AppRoutingModule,
    InteractivePaycardModule,

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
