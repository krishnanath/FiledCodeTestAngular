import { Component, OnInit } from '@angular/core';
import { CardLabel, FormLabel } from 'ngx-interactive-paycard';

import { from } from 'rxjs';

 

 

@Component({
  selector: 'app-credit-card-dto',
  templateUrl: './credit-card-dto.component.html',
  styleUrls: ['./credit-card-dto.component.scss'],
 

})


export class CreditCardDTOComponent implements OnInit {

  title = 'FiledAngularTest';
   
  cardNumberFormat = "#### #### #### ####";
  cardNumberMask = "#### #### #### ####";
  //ex: Optional cardLabels - Spanish
  cardLabel: CardLabel = {
    expires: 'VALID THRU',
    cardHolder: 'Cardholder Name',
    fullName: 'Enter Full Name',
    mm: 'MM',
    yy: 'AA',
};
formLabel: FormLabel = {
  cardNumber: 'Card Number',
  cardHolderName: 'Cardholder Name',
  expirationDate: 'Expiration Date',
  expirationMonth: 'Mounth',
  expirationYear: 'Year',
  cvv: 'CVV',
  submitButton: 'SUBMIT',
};
  
onSubmitEvent($event) {
 console.log(this.formLabel);
 
}
  constructor() { }
  

ngOnInit(){
 

}
}