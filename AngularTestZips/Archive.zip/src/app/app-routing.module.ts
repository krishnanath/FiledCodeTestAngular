import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreditCardDTOComponent } from './credit-card-dto/credit-card-dto.component';

const routes: Routes = [
  {path:'make-payment', component:CreditCardDTOComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
