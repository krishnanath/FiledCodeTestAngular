import { Component, OnInit } from '@angular/core';
import {Store} from '@ngrx/store';
import { Appstate } from '../../../app.state'
import {Creditcard} from '../../../models/creditcard.model'
import * as CreditcardActions from '../../../actions/creditcard.actons';
import {FormControl, FormGroup, Validators} from '@angular/forms'
// import {Observable} from 'rxjs'

import { DatePipe } from '@angular/common';
 
 
@Component({
  selector: 'app-add-credicard',
  templateUrl: './add-credicard.component.html',
  styleUrls: ['./add-credicard.component.scss']
})
export class AddCredicardComponent implements OnInit {

  submitted = false;

  constructor(private store: Store<Appstate>
     
    ) { 

    }

  addCreditcard(cardNumber, cardHolderName, expirationDate, totalAmount, cvv ){
    this.store.dispatch(new CreditcardActions.AddCreditcard({cardNumber: cardNumber,cardHolderName:cardHolderName, expirationDate: expirationDate,  totalAmount: totalAmount,  cvv: cvv}))
  }

  creditcardValidation = new FormGroup({
    name: new FormControl('', Validators.required),
    cardnumber: new FormControl ('',  Validators.required),
    expirationDate:new FormControl('', Validators.required),
    cvv: new FormControl ('',  Validators.required),
    amount: new FormControl ('',  Validators.required),






  
  })

  ngOnInit(): void {
  }

  onReset() {
    this.submitted = false;
    this.creditcardValidation.reset();
}
  

}
